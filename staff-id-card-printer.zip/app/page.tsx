"use client"

import type React from "react"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import Logo from "@/components/logo"
import { useState } from "react"

export default function Home() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Simulate authentication
    setTimeout(() => {
      setIsLoading(false)

      // For demo purposes, we'll just redirect to dashboard
      window.location.href = "/dashboard"

      // In a real app, you would validate credentials here
      // const formData = new FormData(e.currentTarget);
      // const email = formData.get("email") as string;
      // const password = formData.get("password") as string;

      // if (email === "admin@example.com" && password === "password") {
      //   window.location.href = "/dashboard";
      // } else {
      //   setError("Invalid email or password");
      // }
    }, 1000)
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center flex flex-col items-center">
          <Logo size="large" />
          <h1 className="text-xl md:text-2xl font-bold mt-4">Staff ID Card Printer</h1>
          <p className="text-muted-foreground">Ghana Immigration Service</p>
        </div>
        <div className="rounded-lg border bg-card shadow-sm">
          <div className="p-4 md:p-6">
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label
                    htmlFor="email"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="m@example.com"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label
                      htmlFor="password"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Password
                    </label>
                    <Link href="/forgot-password" className="text-xs text-primary hover:underline">
                      Forgot password?
                    </Link>
                  </div>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    required
                  />
                </div>
                {error && <div className="text-sm text-red-500 font-medium">{error}</div>}
                <Button type="submit" className="w-full bg-green-700 hover:bg-green-800" disabled={isLoading}>
                  {isLoading ? "Logging in..." : "Login"}
                </Button>
              </div>
            </form>
          </div>
        </div>
        <div className="mt-4 text-center text-sm text-gray-500">Friendship With Vigilance</div>
      </div>
    </div>
  )
}

