"use client"

import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import StaffList from "@/components/staff-list"
import Sidebar from "@/components/sidebar"
import { useState } from "react"
import { usePathname } from "next/navigation"

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const pathname = usePathname()

  return (
    <div className="flex min-h-screen bg-gray-50 flex-col md:flex-row">
      <Sidebar currentPath={pathname} />

      {/* Main content */}
      <div className="flex-1 p-4 md:p-6 pt-16 md:pt-6 md:ml-64">
        <div className="mb-6">
          <h1 className="text-xl md:text-2xl font-bold">Staff Management</h1>
          <p className="text-gray-500">Manage staff members and ID cards</p>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
          <Input
            className="pl-10"
            placeholder="Search by name, ID or department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <StaffList searchQuery={searchQuery} />
      </div>
    </div>
  )
}

