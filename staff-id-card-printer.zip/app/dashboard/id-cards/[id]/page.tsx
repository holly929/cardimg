"use client"

import { ArrowLeft, Printer, Download, Settings, Layers } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import Sidebar from "@/components/sidebar"
import { usePathname } from "next/navigation"
import { toast } from "@/hooks/use-toast"
import IDCard from "@/components/id-card"
import { useState } from "react"
import SaveButton from "@/components/save-button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
} from "@/components/ui/sheet"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { FieldLabelsProvider, useFieldLabels } from "@/contexts/field-labels-context"

// Field options for ID cards
const AVAILABLE_FIELDS = [
  { id: "name", label: "Name", required: true },
  { id: "position", label: "Position", required: true },
  { id: "idNumber", label: "ID Number", required: false },
  { id: "department", label: "Department", required: false },
  { id: "expiryDate", label: "Expiry Date", required: false },
  { id: "email", label: "Email", required: false },
  { id: "phone", label: "Phone", required: false },
  { id: "dateOfBirth", label: "Date of Birth", required: false },
  { id: "gender", label: "Gender", required: false },
  { id: "dateOfIssue", label: "Date of Issue", required: false },
  { id: "employeeNo", label: "Employee Number", required: false },
]

function IDCardViewContent({ params }: { params: { id: string } }) {
  const pathname = usePathname()
  const { fieldLabels } = useFieldLabels()
  const [cardSize, setCardSize] = useState<"small" | "standard" | "large">("standard")
  const [printOrientation, setPrintOrientation] = useState<"portrait" | "landscape">("landscape")
  const [showBorder, setShowBorder] = useState(true)
  const [showQrCode, setShowQrCode] = useState(true)
  const [visibleFields, setVisibleFields] = useState<string[]>([
    "name",
    "position",
    "idNumber",
    "department",
    "expiryDate",
    "dateOfBirth",
    "gender",
    "dateOfIssue",
  ])
  const [isDownloading, setIsDownloading] = useState(false)

  // Mock staff data for the current ID
  const staffData = {
    id: params.id,
    name: "Kofi Mensah",
    position: "Immigration Officer",
    idNumber: "GIS-601",
    expiryDate: "6/30/2025",
    department: "Immigration",
    photo: "/placeholder.svg?height=150&width=150",
    email: "kofi.mensah@example.com",
    phone: "+233 20 123 4567",
    dateOfBirth: "15/05/1985",
    gender: "Male",
    dateOfIssue: "01/07/2023",
    employeeNo: "78964500",
  }

  // Mock data for bulk printing
  const bulkStaffData = [
    staffData,
    {
      id: "2",
      name: "Ama Owusu",
      position: "Senior Officer",
      idNumber: "GIS-042",
      expiryDate: "7/15/2025",
      department: "Administration",
      photo: "/placeholder.svg?height=150&width=150",
      email: "ama.owusu@example.com",
      phone: "+233 20 987 6543",
      dateOfBirth: "22/11/1982",
      gender: "Female",
      dateOfIssue: "15/08/2023",
      employeeNo: "78964501",
    },
    {
      id: "3",
      name: "Kwame Asante",
      position: "Field Agent",
      idNumber: "GIS-015",
      expiryDate: "5/22/2025",
      department: "Field Operations",
      photo: "/placeholder.svg?height=150&width=150",
      email: "kwame.asante@example.com",
      phone: "+233 24 555 7890",
      dateOfBirth: "03/09/1990",
      gender: "Male",
      dateOfIssue: "10/06/2023",
      employeeNo: "78964502",
    },
  ]

  const [selectedStaff, setSelectedStaff] = useState<string[]>([params.id])

  const handlePrint = () => {
    // Apply print-specific styles
    document.body.classList.add("printing")

    // Set print orientation
    const style = document.createElement("style")
    style.innerHTML = `
      @page {
        size: ${printOrientation};
      }
      .id-card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
        padding: 20px;
      }
      .id-card-wrapper {
        break-inside: avoid;
        page-break-inside: avoid;
        margin-bottom: 20px;
      }
    `
    document.head.appendChild(style)

    toast({
      title: "Printing ID Card",
      description: `Printing ${selectedStaff.length > 1 ? "multiple" : "single"} ID card(s)...`,
    })

    window.print()

    // Clean up
    document.body.classList.remove("printing")
    document.head.removeChild(style)
  }

  const handleDownload = async () => {
    setIsDownloading(true)

    // Simulate download
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast({
      title: "Downloading ID Card",
      description: `ID card PDF has been downloaded for ${selectedStaff.length} staff member(s).`,
    })

    setIsDownloading(false)
  }

  const toggleStaffSelection = (id: string) => {
    setSelectedStaff((prev) => (prev.includes(id) ? prev.filter((staffId) => staffId !== id) : [...prev, id]))
  }

  const selectAllStaff = () => {
    setSelectedStaff(bulkStaffData.map((staff) => staff.id))
  }

  const deselectAllStaff = () => {
    setSelectedStaff([])
  }

  const toggleField = (fieldId: string) => {
    // If field is required, don't allow toggling
    if (AVAILABLE_FIELDS.find((f) => f.id === fieldId)?.required) {
      return
    }

    setVisibleFields((prev) => (prev.includes(fieldId) ? prev.filter((id) => id !== fieldId) : [...prev, fieldId]))
  }

  return (
    <div className="flex min-h-screen bg-gray-50 flex-col md:flex-row">
      <Sidebar currentPath={pathname} />

      {/* Main content */}
      <div className="flex-1 p-4 md:p-6 pt-16 md:pt-6 md:ml-64 no-print">
        <div className="mb-6">
          <Link
            href="/dashboard/id-cards"
            className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to ID Cards
          </Link>
        </div>

        <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-xl md:text-2xl font-bold">ID Card Preview</h1>
            <p className="text-gray-500">
              {selectedStaff.length > 1
                ? `Preview and print ${selectedStaff.length} ID cards`
                : `Preview and print ID card for ${staffData.name}`}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={cardSize} onValueChange={(value) => setCardSize(value as any)}>
              <SelectTrigger className="w-full sm:w-[140px]">
                <SelectValue placeholder="Card Size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Small</SelectItem>
                <SelectItem value="standard">Standard</SelectItem>
                <SelectItem value="large">Large</SelectItem>
              </SelectContent>
            </Select>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="flex items-center w-full sm:w-auto">
                  <Layers className="mr-2 h-4 w-4" /> Field Options
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>ID Card Fields</SheetTitle>
                  <SheetDescription>Select which fields to display on the ID card</SheetDescription>
                </SheetHeader>
                <div className="py-4">
                  <div className="space-y-4">
                    {AVAILABLE_FIELDS.map((field) => (
                      <div key={field.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`field-${field.id}`}
                          checked={visibleFields.includes(field.id)}
                          onCheckedChange={() => toggleField(field.id)}
                          disabled={field.required}
                        />
                        <Label htmlFor={`field-${field.id}`} className={field.required ? "font-medium" : ""}>
                          {fieldLabels[field.id as keyof typeof fieldLabels] || field.label}
                          {field.required && <span className="text-red-500 ml-1">*</span>}
                        </Label>
                      </div>
                    ))}

                    <div className="flex items-center space-x-2 pt-2 border-t">
                      <Checkbox
                        id="show-qr-code"
                        checked={showQrCode}
                        onCheckedChange={(checked) => setShowQrCode(checked as boolean)}
                      />
                      <Label htmlFor="show-qr-code">Show QR Code</Label>
                    </div>
                  </div>
                </div>
                <SheetFooter>
                  <p className="text-xs text-gray-500">* Required fields cannot be hidden</p>
                </SheetFooter>
              </SheetContent>
            </Sheet>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="flex items-center w-full sm:w-auto">
                  <Settings className="mr-2 h-4 w-4" /> Print Options
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Print Settings</SheetTitle>
                  <SheetDescription>Customize how your ID cards will be printed</SheetDescription>
                </SheetHeader>
                <div className="py-4 space-y-6">
                  <div className="space-y-2">
                    <Label>Card Size</Label>
                    <RadioGroup
                      value={cardSize}
                      onValueChange={(value) => setCardSize(value as any)}
                      className="flex flex-col space-y-1"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="small" id="small" />
                        <Label htmlFor="small">Small</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="standard" id="standard" />
                        <Label htmlFor="standard">Standard</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="large" id="large" />
                        <Label htmlFor="large">Large</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-2">
                    <Label>Page Orientation</Label>
                    <RadioGroup
                      value={printOrientation}
                      onValueChange={(value) => setPrintOrientation(value as any)}
                      className="flex flex-col space-y-1"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="portrait" id="portrait" />
                        <Label htmlFor="portrait">Portrait</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="landscape" id="landscape" />
                        <Label htmlFor="landscape">Landscape</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="show-border"
                      checked={showBorder}
                      onCheckedChange={(checked) => setShowBorder(checked as boolean)}
                    />
                    <Label htmlFor="show-border">Show border when printing</Label>
                  </div>

                  <div className="space-y-2">
                    <Label>Bulk Printing</Label>
                    <div className="border rounded-md p-3 space-y-3">
                      <div className="flex justify-between">
                        <Label>Select Staff Members</Label>
                        <div className="space-x-2 text-xs">
                          <button onClick={selectAllStaff} className="text-blue-600 hover:underline">
                            Select All
                          </button>
                          <span>|</span>
                          <button onClick={deselectAllStaff} className="text-blue-600 hover:underline">
                            Deselect All
                          </button>
                        </div>
                      </div>

                      <div className="space-y-1 max-h-40 overflow-y-auto">
                        {bulkStaffData.map((staff) => (
                          <div key={staff.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`staff-${staff.id}`}
                              checked={selectedStaff.includes(staff.id)}
                              onCheckedChange={() => toggleStaffSelection(staff.id)}
                            />
                            <Label htmlFor={`staff-${staff.id}`} className="text-sm">
                              {staff.name} ({staff.position})
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>

            <Button
              variant="outline"
              className="flex items-center w-full sm:w-auto"
              onClick={handlePrint}
              disabled={selectedStaff.length === 0}
            >
              <Printer className="mr-2 h-4 w-4" /> Print ID Card
            </Button>

            <SaveButton
              onClick={handleDownload}
              isLoading={isDownloading}
              fullWidth={true}
              className="sm:w-auto"
              disabled={selectedStaff.length === 0}
              successMessage="ID Card downloaded"
              successSubMessage={`ID card PDF has been downloaded for ${selectedStaff.length} staff member(s).`}
            >
              <Download className="mr-2 h-4 w-4" /> Download PDF
            </SaveButton>
          </div>
        </div>

        {/* Preview Area */}
        <div className="flex flex-col items-center">
          <h2 className="text-lg font-medium mb-4">Preview</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-8">
            {selectedStaff.length > 0 ? (
              bulkStaffData
                .filter((staff) => selectedStaff.includes(staff.id))
                .map((staff) => (
                  <div key={staff.id} className="flex justify-center">
                    <IDCard staffData={staff} size={cardSize} showFields={visibleFields} showQrCode={showQrCode} />
                  </div>
                ))
            ) : (
              <div className="col-span-full text-center py-8">
                <p className="text-gray-500">No ID cards selected for printing</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Print-only content */}
      <div className="hidden print:block">
        <div className="id-card-container">
          {bulkStaffData
            .filter((staff) => selectedStaff.includes(staff.id))
            .map((staff) => (
              <div key={staff.id} className="id-card-wrapper">
                <IDCard staffData={staff} size={cardSize} showFields={visibleFields} showQrCode={showQrCode} />
              </div>
            ))}
        </div>
      </div>
    </div>
  )
}

export default function IDCardView({ params }: { params: { id: string } }) {
  return (
    <FieldLabelsProvider>
      <IDCardViewContent params={params} />
    </FieldLabelsProvider>
  )
}

