"use client"

import { Search, CreditCard, Printer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Sidebar from "@/components/sidebar"
import { usePathname, useRouter } from "next/navigation"
import { useState } from "react"
import Link from "next/link"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "@/hooks/use-toast"

// Mock staff data
const staffMembers = [
  {
    id: "1",
    name: "Kofi Mensah",
    position: "Immigration Officer",
    idNumber: "GIS-601",
    expiryDate: "6/30/2025",
    department: "Immigration",
  },
  {
    id: "2",
    name: "Ama Owusu",
    position: "Senior Officer",
    idNumber: "GIS-042",
    expiryDate: "7/15/2025",
    department: "Administration",
  },
  {
    id: "3",
    name: "Kwame Asante",
    position: "Field Agent",
    idNumber: "GIS-015",
    expiryDate: "5/22/2025",
    department: "Field Operations",
  },
  {
    id: "4",
    name: "Abena Sarpong",
    position: "HR Manager",
    idNumber: "GIS-078",
    expiryDate: "8/10/2025",
    department: "Human Resources",
  },
  {
    id: "5",
    name: "Kwesi Boateng",
    position: "Senior Inspector",
    idNumber: "GIS-103",
    expiryDate: "9/5/2025",
    department: "Inspection",
  },
]

export default function IDCards() {
  const [searchQuery, setSearchQuery] = useState("")
  const pathname = usePathname()
  const router = useRouter()
  const [selectedStaff, setSelectedStaff] = useState<string[]>([])

  const filteredStaff = staffMembers.filter(
    (staff) =>
      staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.idNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.department.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const toggleStaffSelection = (id: string) => {
    setSelectedStaff((prev) => (prev.includes(id) ? prev.filter((staffId) => staffId !== id) : [...prev, id]))
  }

  const selectAllStaff = () => {
    setSelectedStaff(filteredStaff.map((staff) => staff.id))
  }

  const deselectAllStaff = () => {
    setSelectedStaff([])
  }

  const handleBulkPrint = () => {
    if (selectedStaff.length === 0) {
      toast({
        title: "No staff selected",
        description: "Please select at least one staff member to print ID cards.",
        variant: "destructive",
      })
      return
    }

    // Navigate to the first selected staff member's ID card page
    // The page will handle showing all selected cards
    router.push(`/dashboard/id-cards/${selectedStaff[0]}`)
  }

  return (
    <div className="flex min-h-screen bg-gray-50 flex-col md:flex-row">
      <Sidebar currentPath={pathname} />

      {/* Main content */}
      <div className="flex-1 p-4 md:p-6 pt-16 md:pt-6 md:ml-64">
        <div className="mb-6">
          <h1 className="text-xl md:text-2xl font-bold">ID Cards</h1>
          <p className="text-gray-500">Manage and print ID cards</p>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
          <Input
            className="pl-10"
            placeholder="Search by name, ID, position or department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {filteredStaff.length > 0 ? (
          <>
            <div className="bg-white rounded-lg border mb-4">
              <div className="p-4 border-b flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">
                    {selectedStaff.length} of {filteredStaff.length} selected
                  </span>
                  <button onClick={selectAllStaff} className="text-xs text-blue-600 hover:underline">
                    Select All
                  </button>
                  <span className="text-xs">|</span>
                  <button onClick={deselectAllStaff} className="text-xs text-blue-600 hover:underline">
                    Deselect All
                  </button>
                </div>

                <Button
                  onClick={handleBulkPrint}
                  className="bg-green-700 hover:bg-green-800 flex items-center w-full sm:w-auto"
                  disabled={selectedStaff.length === 0}
                >
                  <Printer className="mr-2 h-4 w-4" />
                  Print Selected ({selectedStaff.length})
                </Button>
              </div>

              <div className="divide-y">
                {filteredStaff.map((staff) => (
                  <div key={staff.id} className="p-4 flex flex-col sm:flex-row sm:items-center gap-3">
                    <Checkbox
                      id={`select-${staff.id}`}
                      checked={selectedStaff.includes(staff.id)}
                      onCheckedChange={() => toggleStaffSelection(staff.id)}
                      className="mr-4"
                    />

                    <div className="flex-1">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                        <div>
                          <h3 className="font-medium">{staff.name}</h3>
                          <p className="text-sm text-gray-500">
                            {staff.position} • {staff.department}
                          </p>
                        </div>
                        <div className="mt-2 sm:mt-0">
                          <p className="text-sm">
                            <span className="text-gray-500">ID:</span> {staff.idNumber}
                          </p>
                          <p className="text-sm">
                            <span className="text-gray-500">Expires:</span> {staff.expiryDate}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="ml-0 sm:ml-4 mt-2 sm:mt-0">
                      <Button variant="outline" size="sm" asChild className="w-full sm:w-auto">
                        <Link href={`/dashboard/id-cards/${staff.id}`}>View ID</Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div className="bg-white p-6 md:p-8 rounded-lg border text-center">
            <CreditCard className="h-12 w-12 md:h-16 md:w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium mb-2">No ID Cards Found</h3>
            <p className="text-gray-500 mb-4">
              {searchQuery ? "No staff members match your search criteria." : "No staff members have been added yet."}
            </p>
            <Button variant="outline" asChild>
              <Link href="/dashboard">Browse Staff</Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

