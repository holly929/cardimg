"use client"

import type React from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Sidebar from "@/components/sidebar"
import { usePathname } from "next/navigation"
import { useState } from "react"
import { toast } from "@/hooks/use-toast"
import FieldLabelsSettings from "./field-labels"
import { FieldLabelsProvider } from "@/contexts/field-labels-context"
import SaveButton from "@/components/save-button"

export default function Settings() {
  const pathname = usePathname()
  const [isSaving, setIsSaving] = useState(false)

  const handleSaveSettings = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSaving(true)

    // Simulate saving settings
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsSaving(false)
    toast({
      title: "Settings saved",
      description: "Your settings have been saved successfully.",
    })
  }

  return (
    <FieldLabelsProvider>
      <div className="flex min-h-screen bg-gray-50 flex-col md:flex-row">
        <Sidebar currentPath={pathname} />

        {/* Main content */}
        <div className="flex-1 p-4 md:p-6 pt-16 md:pt-6 md:ml-64">
          <div className="mb-6">
            <h1 className="text-xl md:text-2xl font-bold">Settings</h1>
            <p className="text-gray-500">Manage application settings</p>
          </div>

          <Tabs defaultValue="general" className="w-full">
            <TabsList className="mb-4 flex overflow-x-auto">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="field-labels">Field Labels</TabsTrigger>
              <TabsTrigger value="appearance">Appearance</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-4">
              <form onSubmit={handleSaveSettings}>
                <div className="bg-white p-4 md:p-6 rounded-lg border">
                  <h3 className="text-lg font-medium mb-4">Organization Information</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="org-name">Organization Name</Label>
                        <Input id="org-name" defaultValue="KWAHU EAST DISTRICT ASSEMBLY" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="org-code">Organization Code</Label>
                        <Input id="org-code" defaultValue="KEDA" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="org-address">Resident</Label>
                      <Input id="org-address" defaultValue="Ghana Immigration Service, Kwahu East" />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="org-active" defaultChecked />
                      <Label htmlFor="org-active">Organization is active</Label>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-4 md:p-6 rounded-lg border mt-4">
                  <h3 className="text-lg font-medium mb-4">ID Card Settings</h3>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="id-prefix">ID Number Prefix</Label>
                      <Input id="id-prefix" defaultValue="GIS-" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="id-expiry">Default Expiry Period (months)</Label>
                      <Input id="id-expiry" type="number" defaultValue="12" />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="auto-increment" defaultChecked />
                      <Label htmlFor="auto-increment">Auto-increment ID numbers</Label>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex flex-col sm:flex-row sm:justify-end">
                  <SaveButton
                    isLoading={isSaving}
                    fullWidth={true}
                    className="sm:w-auto"
                    successMessage="Settings saved"
                    successSubMessage="Your settings have been saved successfully."
                  >
                    Save Settings
                  </SaveButton>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="field-labels">
              <FieldLabelsSettings />
            </TabsContent>

            {/* Other tabs content... */}
          </Tabs>
        </div>
      </div>
    </FieldLabelsProvider>
  )
}

