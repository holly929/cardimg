"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useFieldLabels, DEFAULT_FIELD_LABELS } from "@/contexts/field-labels-context"
import { useState } from "react"
import { toast } from "@/hooks/use-toast"
import { AlertCircle, RefreshCw } from "lucide-react"
import SaveButton from "@/components/save-button"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Button } from "@/components/ui/button"

export default function FieldLabelsSettings() {
  const { fieldLabels, updateFieldLabel, resetFieldLabels } = useFieldLabels()
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    setIsSaving(true)

    // Simulate saving
    await new Promise((resolve) => setTimeout(resolve, 800))

    toast({
      title: "Field labels saved",
      description: "Your custom field labels have been saved successfully.",
    })

    setIsSaving(false)
  }

  return (
    <div className="bg-white p-4 md:p-6 rounded-lg border">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
        <h3 className="text-lg font-medium">ID Card Field Labels</h3>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline" size="sm" className="flex items-center w-full sm:w-auto">
              <RefreshCw className="mr-2 h-4 w-4" />
              Reset to Default
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Reset field labels?</AlertDialogTitle>
              <AlertDialogDescription>
                This will reset all field labels to their default values. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={resetFieldLabels}>Reset</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      <div className="text-sm text-amber-600 bg-amber-50 p-3 rounded-md mb-4 flex items-start">
        <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
        <p>
          Customizing field labels will change how information is displayed on ID cards. These changes will apply to all
          new and existing ID cards.
        </p>
      </div>

      <div className="space-y-4">
        <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wider">Card Header</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="organization">Organization Name</Label>
            <Input
              id="organization"
              value={fieldLabels.organization}
              onChange={(e) => updateFieldLabel("organization", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.organization}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="subOrganization">Sub-Organization Name</Label>
            <Input
              id="subOrganization"
              value={fieldLabels.subOrganization}
              onChange={(e) => updateFieldLabel("subOrganization", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.subOrganization}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="title">Card Title</Label>
          <Input
            id="title"
            value={fieldLabels.title}
            onChange={(e) => updateFieldLabel("title", e.target.value)}
            placeholder={DEFAULT_FIELD_LABELS.title}
          />
        </div>

        <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wider pt-2">Staff Information Fields</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name Label</Label>
            <Input
              id="name"
              value={fieldLabels.name}
              onChange={(e) => updateFieldLabel("name", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.name}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="position">Position Label</Label>
            <Input
              id="position"
              value={fieldLabels.position}
              onChange={(e) => updateFieldLabel("position", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.position}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="department">Department Label</Label>
            <Input
              id="department"
              value={fieldLabels.department}
              onChange={(e) => updateFieldLabel("department", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.department}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="idNumber">ID Number Label</Label>
            <Input
              id="idNumber"
              value={fieldLabels.idNumber}
              onChange={(e) => updateFieldLabel("idNumber", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.idNumber}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="expiryDate">Expiry Date Label</Label>
            <Input
              id="expiryDate"
              value={fieldLabels.expiryDate}
              onChange={(e) => updateFieldLabel("expiryDate", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.expiryDate}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email Label</Label>
            <Input
              id="email"
              value={fieldLabels.email}
              onChange={(e) => updateFieldLabel("email", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.email}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Label</Label>
            <Input
              id="phone"
              value={fieldLabels.phone}
              onChange={(e) => updateFieldLabel("phone", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.phone}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="dateOfBirth">Date of Birth Label</Label>
            <Input
              id="dateOfBirth"
              value={fieldLabels.dateOfBirth}
              onChange={(e) => updateFieldLabel("dateOfBirth", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.dateOfBirth}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="gender">Gender Label</Label>
            <Input
              id="gender"
              value={fieldLabels.gender}
              onChange={(e) => updateFieldLabel("gender", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.gender}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="dateOfIssue">Date of Issue Label</Label>
            <Input
              id="dateOfIssue"
              value={fieldLabels.dateOfIssue}
              onChange={(e) => updateFieldLabel("dateOfIssue", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.dateOfIssue}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="employeeNo">Employee Number Label</Label>
            <Input
              id="employeeNo"
              value={fieldLabels.employeeNo}
              onChange={(e) => updateFieldLabel("employeeNo", e.target.value)}
              placeholder={DEFAULT_FIELD_LABELS.employeeNo}
            />
          </div>
        </div>

        <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wider pt-2">Card Footer</h4>
        <div className="space-y-2">
          <Label htmlFor="footer">Footer Text</Label>
          <Input
            id="footer"
            value={fieldLabels.footer}
            onChange={(e) => updateFieldLabel("footer", e.target.value)}
            placeholder={DEFAULT_FIELD_LABELS.footer}
          />
        </div>

        <div className="pt-4 flex flex-col sm:flex-row sm:justify-end">
          <SaveButton
            onClick={handleSave}
            isLoading={isSaving}
            fullWidth={true}
            className="sm:w-auto"
            successMessage="Field labels saved"
            successSubMessage="Your custom field labels have been saved successfully."
          >
            Save Field Labels
          </SaveButton>
        </div>
      </div>
    </div>
  )
}

