"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

// Default field labels
export const DEFAULT_FIELD_LABELS = {
  name: "Name",
  position: "Position",
  department: "Department",
  idNumber: "ID Number",
  expiryDate: "Expiry Date",
  email: "Email",
  phone: "Phone",
  title: "OFFICIAL ID CARD",
  organization: "GHANA IMMIGRATION SERVICE",
  subOrganization: "KWAHU EAST DISTRICT ASSEMBLY",
  footer: "Friendship With Vigilance",
  dateOfBirth: "D.O.B",
  gender: "Gender",
  dateOfIssue: "Date of Issue",
  employeeNo: "Emp No.",
}

type FieldLabels = typeof DEFAULT_FIELD_LABELS

interface FieldLabelsContextType {
  fieldLabels: FieldLabels
  updateFieldLabel: (key: keyof FieldLabels, value: string) => void
  resetFieldLabels: () => void
}

const FieldLabelsContext = createContext<FieldLabelsContextType | undefined>(undefined)

export function FieldLabelsProvider({ children }: { children: React.ReactNode }) {
  // Initialize with default labels or from localStorage if available
  const [fieldLabels, setFieldLabels] = useState<FieldLabels>(() => {
    if (typeof window !== "undefined") {
      const savedLabels = localStorage.getItem("idCardFieldLabels")
      return savedLabels ? JSON.parse(savedLabels) : DEFAULT_FIELD_LABELS
    }
    return DEFAULT_FIELD_LABELS
  })

  // Save to localStorage when labels change
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("idCardFieldLabels", JSON.stringify(fieldLabels))
    }
  }, [fieldLabels])

  const updateFieldLabel = (key: keyof FieldLabels, value: string) => {
    setFieldLabels((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  const resetFieldLabels = () => {
    setFieldLabels(DEFAULT_FIELD_LABELS)
  }

  return (
    <FieldLabelsContext.Provider value={{ fieldLabels, updateFieldLabel, resetFieldLabels }}>
      {children}
    </FieldLabelsContext.Provider>
  )
}

export function useFieldLabels() {
  const context = useContext(FieldLabelsContext)
  if (context === undefined) {
    throw new Error("useFieldLabels must be used within a FieldLabelsProvider")
  }
  return context
}

