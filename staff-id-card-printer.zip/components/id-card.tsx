import Logo from "./logo"
import { useFieldLabels } from "@/contexts/field-labels-context"

interface IDCardProps {
  staffData: {
    id: string
    name: string
    position: string
    idNumber: string
    expiryDate: string
    department: string
    photo: string
    email?: string
    phone?: string
    dateOfBirth?: string
    gender?: string
    dateOfIssue?: string
  }
  size?: "small" | "standard" | "large"
  className?: string
  showFields?: string[]
  showQrCode?: boolean
}

export default function IDCard({
  staffData,
  size = "standard",
  className = "",
  showFields = ["name", "position", "idNumber", "department", "expiryDate", "dateOfBirth", "gender", "dateOfIssue"],
  showQrCode = true,
}: IDCardProps) {
  const { fieldLabels } = useFieldLabels()

  // Size classes for different card dimensions - rectangular ID card
  const sizeClasses = {
    small: "w-full max-w-[256px] h-40 text-xs",
    standard: "w-full max-w-[320px] h-48 text-sm",
    large: "w-full max-w-[384px] h-60 text-base",
  }

  // Photo size classes
  const photoSizes = {
    small: "w-16 h-16",
    standard: "w-20 h-20",
    large: "w-24 h-24",
  }

  // Field mapping for display
  const fieldMapping: Record<string, { label: keyof typeof fieldLabels; value: string }> = {
    name: { label: "name", value: staffData.name },
    position: { label: "position", value: staffData.position },
    department: { label: "department", value: staffData.department },
    idNumber: { label: "idNumber", value: staffData.idNumber },
    expiryDate: { label: "expiryDate", value: staffData.expiryDate },
    email: { label: "email", value: staffData.email || "" },
    phone: { label: "phone", value: staffData.phone || "" },
    dateOfBirth: { label: "dateOfBirth", value: staffData.dateOfBirth || "31/02/2021" },
    gender: { label: "gender", value: staffData.gender || "Male" },
    dateOfIssue: { label: "dateOfIssue", value: staffData.dateOfIssue || "01/03/2023" },
  }

  // Generate a simple QR code URL (in a real app, this would be a proper QR code)
  const qrCodeUrl = `/placeholder.svg?height=60&width=60&text=ID:${staffData.idNumber}`

  return (
    <div
      className={`relative bg-white rounded-lg overflow-hidden shadow-md print:shadow-none ${sizeClasses[size]} ${className}`}
    >
      {/* Card hole punch simulation */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-2 bg-gray-200 rounded-b-lg"></div>

      {/* Background pattern for header */}
      <div className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-r from-green-700 to-green-600 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-16 h-16 border-2 border-white rounded-full transform rotate-45"></div>
          <div className="absolute top-0 right-1/4 w-12 h-12 border-2 border-white transform rotate-12"></div>
          <div className="absolute bottom-0 left-1/3 w-20 h-20 border-2 border-white rounded-lg transform -rotate-12"></div>
        </div>
      </div>

      {/* Card Content */}
      <div className="relative h-full p-3 flex flex-col">
        {/* Header with logo */}
        <div className="flex justify-end mb-2 z-10">
          <div className="flex items-center">
            <Logo size="small" />
          </div>
        </div>

        {/* Main content */}
        <div className="flex flex-1">
          {/* Photo */}
          <div className="mr-3">
            <div className={`${photoSizes[size]} rounded-full overflow-hidden border-2 border-white bg-white`}>
              <img
                src={staffData.photo || "/placeholder.svg"}
                alt={staffData.name}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Name and title */}
          <div className="flex flex-col justify-center">
            <h3
              className={`font-bold text-green-800 ${
                size === "small" ? "text-sm" : size === "large" ? "text-xl" : "text-lg"
              }`}
            >
              {staffData.name}
            </h3>
            <p className="text-gray-600">{staffData.position}</p>
          </div>
        </div>

        {/* Details grid */}
        <div className="grid grid-cols-3 gap-x-2 gap-y-1 mt-2 border-t pt-2">
          {showFields
            .filter((field) => field !== "name" && field !== "position" && fieldMapping[field]?.value)
            .map((field) => (
              <div key={field}>
                <div className="text-gray-500 text-xs">{fieldLabels[fieldMapping[field].label]}:</div>
                <div className="font-medium truncate">{fieldMapping[field].value}</div>
              </div>
            ))}

          {/* QR Code */}
          {showQrCode && (
            <div className="row-span-2 flex justify-end items-center">
              <div className="w-12 h-12">
                <img src={qrCodeUrl || "/placeholder.svg"} alt="QR Code" className="w-full h-full" />
              </div>
            </div>
          )}

          {/* Signature */}
          <div className="col-span-2">
            <div className="text-gray-500 text-xs">Signature:</div>
            <div className="h-6 border-b border-gray-400 mt-1"></div>
          </div>
        </div>
      </div>
    </div>
  )
}

