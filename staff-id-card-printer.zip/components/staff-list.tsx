"use client"

import { User, Calendar, Trash, Pencil, Printer, CreditCard } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { toast } from "@/hooks/use-toast"
import Link from "next/link"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface StaffMember {
  id: string
  name: string
  position: string
  idNumber: string
  expiryDate: string
}

const initialStaffMembers: StaffMember[] = [
  {
    id: "1",
    name: "Kofi Mensah",
    position: "Immigration Officer",
    idNumber: "GIS-601",
    expiryDate: "6/30/2025",
  },
  {
    id: "2",
    name: "Ama Owusu",
    position: "Senior Officer",
    idNumber: "GIS-042",
    expiryDate: "7/15/2025",
  },
  {
    id: "3",
    name: "Kwame Asante",
    position: "Field Agent",
    idNumber: "GIS-015",
    expiryDate: "5/22/2025",
  },
  {
    id: "4",
    name: "Abena Sarpong",
    position: "HR Manager",
    idNumber: "GIS-078",
    expiryDate: "8/10/2025",
  },
  {
    id: "5",
    name: "Kwesi Boateng",
    position: "Senior Inspector",
    idNumber: "GIS-103",
    expiryDate: "9/5/2025",
  },
]

interface StaffListProps {
  searchQuery?: string
}

export default function StaffList({ searchQuery = "" }: StaffListProps) {
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>(initialStaffMembers)
  const [staffToDelete, setStaffToDelete] = useState<StaffMember | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const filteredStaff = staffMembers.filter(
    (staff) =>
      staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.idNumber.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleDeleteStaff = (staff: StaffMember) => {
    setStaffToDelete(staff)
    setIsDialogOpen(true)
  }

  const confirmDelete = () => {
    if (staffToDelete) {
      setStaffMembers(staffMembers.filter((staff) => staff.id !== staffToDelete.id))
      toast({
        title: "Staff Deleted",
        description: `${staffToDelete.name} has been removed from the system.`,
      })
      setIsDialogOpen(false)
      setStaffToDelete(null)
    }
  }

  const handlePrintID = (staff: StaffMember) => {
    toast({
      title: "Redirecting to ID Card",
      description: `Opening ID card for ${staff.name}...`,
    })
  }

  return (
    <>
      {filteredStaff.length === 0 ? (
        <div className="bg-white p-6 md:p-8 rounded-lg border text-center">
          <User className="h-12 w-12 md:h-16 md:w-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium mb-2">No Staff Found</h3>
          <p className="text-gray-500 mb-4">
            {searchQuery ? "No staff members match your search criteria." : "No staff members have been added yet."}
          </p>
          <Button asChild className="bg-green-700 hover:bg-green-800">
            <a href="/add-staff">Add New Staff</a>
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredStaff.map((staff) => (
            <div key={staff.id} className="border rounded-lg bg-white p-4 hover:shadow-md transition-shadow">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div>
                  <h3 className="font-medium">{staff.name}</h3>
                  <p className="text-sm text-gray-500">{staff.position}</p>
                </div>
                <div className="mt-2 sm:mt-0 space-y-1">
                  <div className="flex items-center text-sm text-gray-500">
                    <User className="mr-2 h-4 w-4" />
                    ID: {staff.idNumber}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="mr-2 h-4 w-4" />
                    Expires: {staff.expiryDate}
                  </div>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2 justify-start sm:justify-end">
                <Button variant="outline" size="sm" className="flex items-center">
                  <Pencil className="mr-1 h-3 w-3" /> Edit
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center text-red-600 hover:text-red-700"
                  onClick={() => handleDeleteStaff(staff)}
                >
                  <Trash className="mr-1 h-3 w-3" /> Delete
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center text-green-700 hover:text-green-800"
                  asChild
                >
                  <Link href={`/dashboard/id-cards/${staff.id}`} onClick={() => handlePrintID(staff)}>
                    <CreditCard className="mr-1 h-3 w-3" /> View ID
                  </Link>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center text-blue-600 hover:text-blue-700"
                  asChild
                >
                  <Link href={`/dashboard/id-cards/${staff.id}`}>
                    <Printer className="mr-1 h-3 w-3" /> Print ID
                  </Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {staffToDelete?.name}'s record from the system. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

