"use client"

import { User, CreditCard, Settings, Plus, Menu, X } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import Logo from "./logo"
import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"

interface SidebarProps {
  currentPath: string
}

export default function Sidebar({ currentPath }: SidebarProps) {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  // Close sidebar when route changes
  useEffect(() => {
    setIsOpen(false)
  }, [pathname])

  // Close sidebar when escape key is pressed
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsOpen(false)
      }
    }

    window.addEventListener("keydown", handleEsc)
    return () => window.removeEventListener("keydown", handleEsc)
  }, [])

  // Prevent scrolling when sidebar is open on mobile
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }

    return () => {
      document.body.style.overflow = ""
    }
  }, [isOpen])

  return (
    <>
      {/* Mobile menu button - only visible on small screens */}
      <button
        className="fixed top-4 left-4 z-50 md:hidden bg-white p-2 rounded-md shadow-md"
        onClick={() => setIsOpen(!isOpen)}
        aria-label={isOpen ? "Close menu" : "Open menu"}
        aria-expanded={isOpen}
      >
        {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </button>

      {/* Sidebar - hidden on small screens unless toggled */}
      <div
        className={`fixed inset-y-0 left-0 transform ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } md:translate-x-0 transition duration-200 ease-in-out md:relative md:w-64 border-r bg-white h-screen flex flex-col z-40`}
      >
        <div className="p-4 border-b flex flex-col items-center">
          <Logo size="medium" />
          <h2 className="font-bold text-sm mt-2">KWAHU EAST</h2>
          <h2 className="font-bold text-sm">DISTRICT ASSEMBLY</h2>
          <p className="text-xs text-green-700 mt-1">Ghana Immigration Service</p>
        </div>
        <nav className="p-2 space-y-1 flex-1 overflow-y-auto">
          <Link
            href="/dashboard"
            className={`flex items-center gap-2 p-3 rounded-md ${
              currentPath === "/dashboard"
                ? "bg-green-50 text-green-700 font-medium"
                : "text-gray-600 hover:bg-gray-100"
            }`}
            onClick={() => setIsOpen(false)}
          >
            <User className="h-5 w-5" />
            Staff
          </Link>
          <Link
            href="/dashboard/id-cards"
            className={`flex items-center gap-2 p-3 rounded-md ${
              currentPath === "/dashboard/id-cards"
                ? "bg-green-50 text-green-700 font-medium"
                : "text-gray-600 hover:bg-gray-100"
            }`}
            onClick={() => setIsOpen(false)}
          >
            <CreditCard className="h-5 w-5" />
            ID Cards
          </Link>
          <Link
            href="/dashboard/settings"
            className={`flex items-center gap-2 p-3 rounded-md ${
              currentPath === "/dashboard/settings"
                ? "bg-green-50 text-green-700 font-medium"
                : "text-gray-600 hover:bg-gray-100"
            }`}
            onClick={() => setIsOpen(false)}
          >
            <Settings className="h-5 w-5" />
            Settings
          </Link>
        </nav>
        <div className="p-4 mt-auto">
          <Button className="w-full bg-green-700 hover:bg-green-800" asChild>
            <Link href="/add-staff" onClick={() => setIsOpen(false)}>
              <Plus className="mr-2 h-4 w-4" /> Add Staff
            </Link>
          </Button>
          <div className="text-xs text-center text-gray-500 mt-4 pb-2">Friendship With Vigilance</div>
        </div>
      </div>

      {/* Overlay to close sidebar on mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden"
          onClick={() => setIsOpen(false)}
          aria-hidden="true"
        />
      )}
    </>
  )
}

