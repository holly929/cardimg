import Image from "next/image"
import Link from "next/link"

export default function Logo({ size = "medium" }: { size?: "small" | "medium" | "large" }) {
  const dimensions = {
    small: { width: 40, height: 40 },
    medium: { width: 60, height: 60 },
    large: { width: 80, height: 80 },
  }

  return (
    <Link href="/dashboard" className="flex flex-col items-center">
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Ghana_Immigration_Service_logo.jpg-1Sm86uqTPYezC1KBB0EYnKJ5nagcEb.jpeg"
        alt="Ghana Immigration Service Logo"
        width={dimensions[size].width}
        height={dimensions[size].height}
        className="rounded-full"
        priority
      />
    </Link>
  )
}

