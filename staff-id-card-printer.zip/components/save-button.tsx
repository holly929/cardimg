"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"
import { useState, useEffect } from "react"
import SuccessPopup from "./success-popup"

interface SaveButtonProps {
  onClick?: () => void | Promise<void>
  isLoading?: boolean
  className?: string
  children?: React.ReactNode
  fullWidth?: boolean
  successMessage?: string
  successSubMessage?: string
  disabled?: boolean
}

export default function SaveButton({
  onClick,
  isLoading: externalLoading,
  className = "",
  children = "Save",
  fullWidth = false,
  successMessage = "Saved successfully",
  successSubMessage = "Your changes have been saved.",
  disabled = false,
}: SaveButtonProps) {
  const [internalLoading, setInternalLoading] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const isLoading = externalLoading !== undefined ? externalLoading : internalLoading

  // Reset loading state if external loading prop changes
  useEffect(() => {
    if (externalLoading === false) {
      setInternalLoading(false)
    }
  }, [externalLoading])

  const handleClick = async () => {
    if (!onClick || isLoading) return

    setInternalLoading(true)
    try {
      await onClick()
      setShowSuccess(true)
    } finally {
      // Only set loading to false if we're managing the state internally
      if (externalLoading === undefined) {
        setInternalLoading(false)
      }
    }
  }

  return (
    <>
      <Button
        onClick={handleClick}
        disabled={isLoading || disabled}
        className={`bg-green-700 hover:bg-green-800 transition-all ${fullWidth ? "w-full" : ""} ${className}`}
      >
        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        {isLoading ? "Saving..." : children}
      </Button>

      <SuccessPopup
        message={successMessage}
        subMessage={successSubMessage}
        isVisible={showSuccess}
        onClose={() => setShowSuccess(false)}
      />
    </>
  )
}

