"use client"

import { useEffect } from "react"
import { CheckCircle2, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface SuccessPopupProps {
  message: string
  subMessage?: string
  isVisible: boolean
  onClose: () => void
  autoCloseDelay?: number
}

export default function SuccessPopup({
  message,
  subMessage,
  isVisible,
  onClose,
  autoCloseDelay = 3000,
}: SuccessPopupProps) {
  // Auto-close the popup after delay
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onClose()
      }, autoCloseDelay)

      return () => clearTimeout(timer)
    }
  }, [isVisible, onClose, autoCloseDelay])

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-4 right-4 z-50 max-w-md w-full sm:w-auto"
        >
          <div className="bg-white rounded-lg shadow-lg border border-green-100 p-4 flex items-start">
            <div className="flex-shrink-0 mr-3">
              <CheckCircle2 className="h-6 w-6 text-green-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-gray-900">{message}</h3>
              {subMessage && <p className="text-sm text-gray-500 mt-1">{subMessage}</p>}
            </div>
            <button
              onClick={onClose}
              className="ml-4 text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500 rounded-full"
              aria-label="Close notification"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

